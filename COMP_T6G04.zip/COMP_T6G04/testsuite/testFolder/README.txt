SimpleTests.java � uma classe JUnit com testes automatizados.

Os 3 testes apresentados s�o o resultado da compila��o dos testes correspondentes (da pasta testsuite)