Neste exemplo testa-se um warning de sem�ntica, dado que a vari�vel out � do tipo int
e uma das vari�veis in � do tipo float, perdendo-se precis�o