/*@mat
	in int A[];
	in int B[];
	in float C;
	out int resultado[];
	out int resultado2[];
	
	resultado = A + B - (A * B);
	
	resultado2 = (resultado * C) / (1 - C);
*/

/* Tem que dar erro dado que
 * a variavel C n�o est� declarada
 * como uma matriz
 */