Este teste deve suceder. Neste teste s�o testados os ranges diretamente
na express�o de c�lculo.