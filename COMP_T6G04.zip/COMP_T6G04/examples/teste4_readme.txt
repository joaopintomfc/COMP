Este teste n�o deve suceder, dado que n�o existem
vari�veis de input