Este teste n�o deve suceder, lan�ando um erro sem�ntico,
dado que n�o � definido um range para as matrizes