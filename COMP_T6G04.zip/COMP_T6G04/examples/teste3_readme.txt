Este teste n�o deve suceder, dado que a variavel resultado
est� declarada como input e a ser usada como output