/*@mat
	out int A[];
	out int B[];
	out float C[];
	out int resultado[];
	out int resultado2[];
	
	resultado = A + B - (A * B);
	
	resultado2 = (resultado * C) / (1 - C);
*/

/* Tem que dar erro dado que
 * que nao existem variaveis
 * de entrada
 */