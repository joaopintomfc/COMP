Este teste n�o deve suceder, lan�ando um erro sem�ntico,
dado que as matrizes de input n�o t�m todas o mesmo tamanho