Este � o teste base do programa. Cont�m um exemplo de uma utiliza��o b�sica
do programa e deve suceder.