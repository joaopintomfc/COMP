public Teste3 {
	
	private int[] A, B;
	private float[] C, resultado;
	
	private void loadVariables(){
		//TODO: code...
	}
	
	public void doOperation(){
		//TODO: more code...
		
		/*@mat
		in int A[16];
		in int B[];
		in float C[];
		in float resultado[];
		
		resultado = A + B - (A * B) - C;
		
		*/
		
		//TODO: even more code...
	}
}